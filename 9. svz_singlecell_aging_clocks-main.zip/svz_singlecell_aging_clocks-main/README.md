# Cell type-specific aging clocks to quantify aging and rejuvenation in neurogenic regions of the brain

Matthew T. Buckley^, Eric Sun^, Benson M. George, Ling Liu, Nicholas Schaum, Lucy Xu, Jaime M. Reyes, Margaret A. Goodell, Irving L. Weissman, Tony Wyss-Coray, Thomas A. Rando, Anne Brunet

^ Equal contribution

This repository contains R scripts used for all the data processing and analysis associated with above manuscript, which can also be accessed at https://doi.org/10.1038/s43587-022-00335-4

